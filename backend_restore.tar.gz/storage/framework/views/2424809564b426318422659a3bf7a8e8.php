<?php echo e($slot); ?>

<?php /**PATH /Users/observer/laravel_projects/Vector Express/backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>